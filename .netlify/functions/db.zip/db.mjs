
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/db.mjs
import crypto from "node:crypto";
var config = { path: "/api/db" };
var BUCKET = "rms-files";
var SUPER_ADMIN = "Admin";
var env = (k) => process.env[k] || "";
var baseUrl = () => {
  const raw = env("SUPABASE_URL").trim();
  try {
    return new URL(raw).origin;
  } catch (e) {
    return raw.replace(/\/+$/, "");
  }
};
var json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8" } });
var envReady = () => !!(env("SUPABASE_URL") && env("SUPABASE_SERVICE_KEY") && env("APP_SECRET") && env("APP_USERS"));
function users() {
  const map = {};
  env("APP_USERS").split(";").map((s) => s.trim()).filter(Boolean).forEach((row) => {
    const parts = row.split(":");
    const [u, p, role, name] = parts;
    if (u && p) map[u.trim()] = { p, role: role || "user", name: name || u };
  });
  return map;
}
var sign = (data) => crypto.createHmac("sha256", env("APP_SECRET")).update(data).digest("base64url");
function makeToken(user, role, name) {
  const payload = Buffer.from(JSON.stringify({ u: user, r: role, n: name, e: Date.now() + 8 * 3600 * 1e3 })).toString("base64url");
  return payload + "." + sign(payload);
}
function checkToken(t) {
  t = String(t || "");
  const i = t.lastIndexOf(".");
  if (i < 1) return null;
  const payload = t.slice(0, i), sig = t.slice(i + 1);
  if (sig !== sign(payload)) return null;
  try {
    const o = JSON.parse(Buffer.from(payload, "base64url").toString());
    return Date.now() > o.e ? null : o;
  } catch (e) {
    return null;
  }
}
function makeResetToken(username) {
  const payload = Buffer.from(JSON.stringify({ u: username, p: "reset", e: Date.now() + 30 * 60 * 1e3 })).toString("base64url");
  return payload + "." + sign(payload);
}
function checkResetToken(t) {
  t = String(t || "");
  const i = t.lastIndexOf(".");
  if (i < 1) return null;
  const payload = t.slice(0, i), sig = t.slice(i + 1);
  if (sig !== sign(payload)) return null;
  try {
    const o = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (o.p !== "reset") return null;
    return Date.now() > o.e ? null : o;
  } catch (e) {
    return null;
  }
}
async function sb(pathname, opts = {}) {
  const res = await fetch(baseUrl() + pathname, {
    ...opts,
    headers: {
      "apikey": env("SUPABASE_SERVICE_KEY"),
      "Authorization": "Bearer " + env("SUPABASE_SERVICE_KEY"),
      ...opts.headers || {}
    }
  });
  const text = await res.text();
  if (!res.ok) throw new Error("Supabase " + res.status + ": " + text.slice(0, 300));
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch (e) {
    return text;
  }
}
var rpc = (fn, params) => sb("/rest/v1/rpc/" + fn, {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify(params || {})
});
var encPath = (p) => p.split("/").map(encodeURIComponent).join("/");
var makeSalt = () => crypto.randomBytes(16).toString("hex");
var hashPw = (pw, salt) => crypto.scryptSync(String(pw || ""), salt, 32).toString("hex");
function verifyPw(pw, salt, hash) {
  try {
    const a = Buffer.from(hashPw(pw, salt), "hex");
    const b = Buffer.from(String(hash || ""), "hex");
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (e) {
    return false;
  }
}
async function dbUser(uname) {
  const rows = await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(uname) + "&select=*");
  return rows && rows[0] ? rows[0] : null;
}
async function userByEmail(email) {
  email = String(email || "").trim();
  if (!email) return null;
  const rows = await sb("/rest/v1/app_users?email=eq." + encodeURIComponent(email) + "&select=*");
  return rows && rows[0] ? rows[0] : null;
}
async function sendResetEmail(toEmail, toName, link) {
  const key = env("RESEND_API_KEY");
  if (!key) throw new Error("email-service \u0938\u0947\u091F \u0928\u0939\u0940\u0902 \u0939\u0948 (Netlify env \u092E\u0947\u0902 RESEND_API_KEY \u091C\u094B\u0921\u093C\u0947\u0902)");
  const from = env("RESET_FROM") || "Road Management <onboarding@resend.dev>";
  const html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#222;line-height:1.6">\u0928\u092E\u0938\u094D\u0924\u0947 ' + (toName || "") + ',<br><br>\u0906\u092A\u0928\u0947 \u0905\u092A\u0928\u0947 Road Management \u0916\u093E\u0924\u0947 \u0915\u0947 \u092A\u093E\u0938\u0935\u0930\u094D\u0921-\u0930\u0940\u0938\u0947\u091F \u0915\u093E \u0905\u0928\u0941\u0930\u094B\u0927 \u0915\u093F\u092F\u093E \u0939\u0948\u0964 \u0928\u092F\u093E \u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0938\u0947\u091F \u0915\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0928\u0940\u091A\u0947 \u0915\u094D\u0932\u093F\u0915 \u0915\u0930\u0947\u0902 (\u092F\u0939 \u0932\u093F\u0902\u0915 30 \u092E\u093F\u0928\u091F \u092E\u0947\u0902 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B \u091C\u093E\u090F\u0917\u093E):<br><br><a href="' + link + '" style="background:#1e3a5f;color:#fff;padding:11px 20px;border-radius:6px;text-decoration:none;display:inline-block">\u{1F511} \u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0930\u0940\u0938\u0947\u091F \u0915\u0930\u0947\u0902</a><br><br>\u092F\u093E \u092F\u0939 \u0932\u093F\u0902\u0915 \u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u092E\u0947\u0902 \u0916\u094B\u0932\u0947\u0902:<br><span style="word-break:break-all;color:#1e3a5f">' + link + "</span><br><br>\u0905\u0917\u0930 \u0906\u092A\u0928\u0947 \u092F\u0939 \u0905\u0928\u0941\u0930\u094B\u0927 \u0928\u0939\u0940\u0902 \u0915\u093F\u092F\u093E, \u0924\u094B \u0907\u0938 \u092E\u0947\u0932 \u0915\u094B \u0905\u0928\u0926\u0947\u0916\u093E \u0915\u0930\u0947\u0902 \u2014 \u0906\u092A\u0915\u093E \u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0928\u0939\u0940\u0902 \u092C\u0926\u0932\u0947\u0917\u093E\u0964</div>";
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Authorization": "Bearer " + key, "content-type": "application/json" },
    body: JSON.stringify({ from, to: [toEmail], subject: "\u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0930\u0940\u0938\u0947\u091F \u2014 Road Management", html })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error("email \u092D\u0947\u091C\u0928\u0947 \u092E\u0947\u0902 \u0924\u094D\u0930\u0941\u091F\u093F: " + t.slice(0, 200));
  }
}
async function tableHasUsers() {
  const r = await sb("/rest/v1/app_users?select=username&limit=1");
  return !!(r && r.length);
}
async function activeAdmins() {
  return await sb("/rest/v1/app_users?role=eq.admin&active=eq.true&select=username") || [];
}
async function ensureSuperAdmin() {
  if (await dbUser(SUPER_ADMIN)) return;
  const salt = makeSalt();
  await sb("/rest/v1/app_users", {
    method: "POST",
    headers: { "content-type": "application/json", "Prefer": "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify([{ username: SUPER_ADMIN, pass_hash: hashPw("Admin@123", salt), pass_salt: salt, role: "admin", name: "Administrator", active: true }])
  });
}
async function seedEnvUsers() {
  const map = users();
  const rows = Object.keys(map).map((k) => {
    const salt = makeSalt();
    return { username: k, pass_hash: hashPw(map[k].p, salt), pass_salt: salt, role: map[k].role, name: map[k].name, active: true };
  });
  if (rows.length) await sb("/rest/v1/app_users", {
    method: "POST",
    headers: { "content-type": "application/json", "Prefer": "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify(rows)
  });
}
function requireAdmin(auth) {
  if (!auth || auth.r !== "admin") {
    const e = new Error("\u0938\u093F\u0930\u094D\u092B\u093C Admin \u2014 \u0905\u0928\u0941\u092E\u0924\u093F \u0928\u0939\u0940\u0902");
    e._code = 403;
    throw e;
  }
}
var cleanUname = (s) => String(s || "").trim();
var EST_STORES = /* @__PURE__ */ new Set(["sheets", "estimates", "master"]);
function estStore(s) {
  s = String(s || "");
  if (!EST_STORES.has(s)) throw new Error("\u0905\u092E\u093E\u0928\u094D\u092F estimator store: " + s);
  return s;
}
var publicUrl = (p) => baseUrl() + "/storage/v1/object/public/" + BUCKET + "/" + encPath(p);
var fileOut = (r) => r ? { id: r.id, name: r.name, mime: r.mime, folder: r.folder, created: r.created_at, url: publicUrl(r.path) } : null;
var db_default = async (req) => {
  if (req.method === "GET") {
    return envReady() ? json({ ok: true, cloud: true }) : json({ ok: false, cloud: false, error: "environment variables \u0938\u0947\u091F \u0928\u0939\u0940\u0902 \u0939\u0948\u0902" }, 503);
  }
  if (req.method !== "POST") return json({ ok: false, error: "method not allowed" }, 405);
  if (!envReady()) return json({ ok: false, error: "server configured \u0928\u0939\u0940\u0902 \u0939\u0948" }, 503);
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return json({ ok: false, error: "bad json" }, 400);
  }
  const op = String(body.op || "");
  const a = body.args || {};
  try {
    if (op === "login") {
      try {
        await ensureSuperAdmin();
      } catch (e) {
      }
      const key = cleanUname(a.user);
      const pass = String(a.pass || "");
      const row = await dbUser(key);
      if (row) {
        if (row.active === false) return json({ ok: true, result: { success: false, message: "\u092F\u0939 \u0916\u093E\u0924\u093E \u0928\u093F\u0937\u094D\u0915\u094D\u0930\u093F\u092F \u0939\u0948 \u2014 Admin \u0938\u0947 \u0938\u0902\u092A\u0930\u094D\u0915 \u0915\u0930\u0947\u0902\u0964" } });
        if (!verifyPw(pass, row.pass_salt, row.pass_hash)) return json({ ok: true, result: { success: false, message: "\u0917\u0932\u0924 \u092F\u0942\u091C\u0930 ID \u092F\u093E \u092A\u093E\u0938\u0935\u0930\u094D\u0921\u0964" } });
        return json({ ok: true, result: { success: true, token: makeToken(row.username, row.role, row.name), role: row.role, name: row.name } });
      }
      if (await tableHasUsers()) {
        return json({ ok: true, result: { success: false, message: "\u0917\u0932\u0924 \u092F\u0942\u091C\u0930 ID \u092F\u093E \u092A\u093E\u0938\u0935\u0930\u094D\u0921\u0964" } });
      }
      const u = users()[key];
      if (!u || u.p !== pass) {
        return json({ ok: true, result: { success: false, message: "\u0917\u0932\u0924 \u092F\u0942\u091C\u0930 ID \u092F\u093E \u092A\u093E\u0938\u0935\u0930\u094D\u0921\u0964" } });
      }
      try {
        await seedEnvUsers();
      } catch (e) {
      }
      return json({ ok: true, result: { success: true, token: makeToken(key, u.role, u.name), role: u.role, name: u.name } });
    }
    if (op === "session") {
      const o = checkToken(a.token);
      return json({ ok: true, result: o ? { valid: true, role: o.r, name: o.n, u: o.u } : { valid: false } });
    }
    if (op === "requestReset") {
      try {
        await ensureSuperAdmin();
      } catch (e) {
      }
      const idf = String(a.idf || "").trim();
      let row = idf.indexOf("@") >= 0 ? await userByEmail(idf) : await dbUser(cleanUname(idf));
      if (!row) row = idf.indexOf("@") >= 0 ? await dbUser(cleanUname(idf)) : await userByEmail(idf);
      if (row && row.email) {
        try {
          const base = String(a.origin || "").replace(/\/+$/, "");
          const link = base + "/?reset=" + encodeURIComponent(makeResetToken(row.username));
          await sendResetEmail(row.email, row.name, link);
        } catch (e) {
          return json({ ok: true, result: { success: false, message: String(e.message || e) } });
        }
      }
      return json({ ok: true, result: { success: true, message: "\u092F\u0926\u093F \u092F\u0939 \u0908\u092E\u0947\u0932/ID \u092A\u0902\u091C\u0940\u0915\u0943\u0924 \u0939\u0948, \u0924\u094B \u0930\u0940\u0938\u0947\u091F-\u0932\u093F\u0902\u0915 \u0909\u0938 \u0908\u092E\u0947\u0932 \u092A\u0930 \u092D\u0947\u091C \u0926\u093F\u092F\u093E \u0917\u092F\u093E \u0939\u0948\u0964 \u0907\u0928\u092C\u0949\u0915\u094D\u0938/\u0938\u094D\u092A\u0948\u092E \u0926\u0947\u0916\u0947\u0902\u0964" } });
    }
    if (op === "resetPassword") {
      const o = checkResetToken(a.token);
      if (!o) return json({ ok: true, result: { success: false, message: "\u0930\u0940\u0938\u0947\u091F-\u0932\u093F\u0902\u0915 \u0905\u092E\u093E\u0928\u094D\u092F \u092F\u093E \u0938\u092E\u092F-\u0938\u092E\u093E\u092A\u094D\u0924 \u2014 \u0926\u094B\u092C\u093E\u0930\u093E \u0905\u0928\u0941\u0930\u094B\u0927 \u0915\u0930\u0947\u0902\u0964" } });
      if (String(a.pass || "").length < 4) return json({ ok: true, result: { success: false, message: "password \u0915\u092E-\u0938\u0947-\u0915\u092E 4 \u0905\u0915\u094D\u0937\u0930 \u0915\u093E \u0939\u094B" } });
      const salt = makeSalt();
      await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(o.u), {
        method: "PATCH",
        headers: { "content-type": "application/json", "Prefer": "return=minimal" },
        body: JSON.stringify({ pass_hash: hashPw(a.pass, salt), pass_salt: salt })
      });
      return json({ ok: true, result: { success: true, user: o.u } });
    }
    const auth = checkToken(body.token);
    if (!auth) return json({ ok: false, error: "unauthorized \u2014 \u0926\u094B\u092C\u093E\u0930\u093E login \u0915\u0930\u0947\u0902" }, 401);
    if (op === "userTargets") {
      const rows = await sb("/rest/v1/app_users?active=eq.true&select=username,name&order=name") || [];
      return json({ ok: true, result: rows.filter((u) => cleanUname(u.username) !== cleanUname(auth.u)) });
    }
    if (op === "userList") {
      requireAdmin(auth);
      const rows = await sb("/rest/v1/app_users?select=username,role,name,email,active,created_at&order=created_at") || [];
      return json({ ok: true, result: rows });
    }
    if (op === "userCreate") {
      requireAdmin(auth);
      const uname = cleanUname(a.user);
      if (!/^[A-Za-z0-9._-]{2,40}$/.test(uname)) throw new Error("username \u092E\u0947\u0902 \u0915\u0947\u0935\u0932 A-Z a-z 0-9 . _ - \u091A\u0932\u0947\u0902\u0917\u0947 (2\u201340 \u0905\u0915\u094D\u0937\u0930)");
      if (String(a.pass || "").length < 4) throw new Error("password \u0915\u092E-\u0938\u0947-\u0915\u092E 4 \u0905\u0915\u094D\u0937\u0930 \u0915\u093E \u0939\u094B");
      if (await dbUser(uname)) throw new Error("\u092F\u0939 username \u092A\u0939\u0932\u0947 \u0938\u0947 \u092E\u094C\u091C\u0942\u0926 \u0939\u0948");
      const role = a.role === "admin" ? "admin" : "user";
      const salt = makeSalt();
      await sb("/rest/v1/app_users", {
        method: "POST",
        headers: { "content-type": "application/json", "Prefer": "return=minimal" },
        body: JSON.stringify([{ username: uname, pass_hash: hashPw(a.pass, salt), pass_salt: salt, role, name: String(a.name || uname), email: String(a.email || "").trim(), active: true }])
      });
      return json({ ok: true, result: true });
    }
    if (op === "userSetPassword") {
      requireAdmin(auth);
      const uname = cleanUname(a.user);
      if (String(a.pass || "").length < 4) throw new Error("password \u0915\u092E-\u0938\u0947-\u0915\u092E 4 \u0905\u0915\u094D\u0937\u0930 \u0915\u093E \u0939\u094B");
      const salt = makeSalt();
      await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(uname), {
        method: "PATCH",
        headers: { "content-type": "application/json", "Prefer": "return=minimal" },
        body: JSON.stringify({ pass_hash: hashPw(a.pass, salt), pass_salt: salt })
      });
      return json({ ok: true, result: true });
    }
    if (op === "userUpdate") {
      requireAdmin(auth);
      const uname = cleanUname(a.user);
      const target = await dbUser(uname);
      if (!target) throw new Error("user \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E");
      let role = a.role === "admin" ? "admin" : "user";
      if (uname === SUPER_ADMIN) role = "admin";
      if (target.role === "admin" && role !== "admin") {
        const admins = await activeAdmins();
        if (admins.length <= 1) throw new Error("\u0915\u092E-\u0938\u0947-\u0915\u092E \u090F\u0915 \u0938\u0915\u094D\u0930\u093F\u092F Admin \u091C\u093C\u0930\u0942\u0930\u0940 \u0939\u0948");
      }
      const patch = { role };
      if (a.name !== void 0) patch.name = String(a.name || uname);
      if (a.email !== void 0) patch.email = String(a.email || "").trim();
      await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(uname), {
        method: "PATCH",
        headers: { "content-type": "application/json", "Prefer": "return=minimal" },
        body: JSON.stringify(patch)
      });
      return json({ ok: true, result: true });
    }
    if (op === "userSetActive") {
      requireAdmin(auth);
      const uname = cleanUname(a.user);
      if (!a.active && uname === SUPER_ADMIN) throw new Error("Super Admin \u0915\u094B \u0928\u093F\u0937\u094D\u0915\u094D\u0930\u093F\u092F \u0928\u0939\u0940\u0902 \u0915\u093F\u092F\u093E \u091C\u093E \u0938\u0915\u0924\u093E");
      if (uname === cleanUname(auth.u)) throw new Error("\u0906\u092A \u0938\u094D\u0935\u092F\u0902 \u0915\u094B \u0928\u093F\u0937\u094D\u0915\u094D\u0930\u093F\u092F \u0928\u0939\u0940\u0902 \u0915\u0930 \u0938\u0915\u0924\u0947");
      if (!a.active) {
        const target = await dbUser(uname);
        if (target && target.role === "admin") {
          const admins = await activeAdmins();
          if (admins.length <= 1) throw new Error("\u0915\u092E-\u0938\u0947-\u0915\u092E \u090F\u0915 \u0938\u0915\u094D\u0930\u093F\u092F Admin \u091C\u093C\u0930\u0942\u0930\u0940 \u0939\u0948");
        }
      }
      await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(uname), {
        method: "PATCH",
        headers: { "content-type": "application/json", "Prefer": "return=minimal" },
        body: JSON.stringify({ active: !!a.active })
      });
      return json({ ok: true, result: true });
    }
    if (op === "userDelete") {
      requireAdmin(auth);
      const uname = cleanUname(a.user);
      if (uname === SUPER_ADMIN) throw new Error("Super Admin \u0915\u094B \u0939\u091F\u093E\u092F\u093E \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u0924\u093E");
      if (uname === cleanUname(auth.u)) throw new Error("\u0906\u092A \u0938\u094D\u0935\u092F\u0902 \u0915\u094B \u0928\u0939\u0940\u0902 \u0939\u091F\u093E \u0938\u0915\u0924\u0947");
      const target = await dbUser(uname);
      if (target && target.role === "admin") {
        const admins = await activeAdmins();
        if (admins.length <= 1) throw new Error("\u0915\u092E-\u0938\u0947-\u0915\u092E \u090F\u0915 \u0938\u0915\u094D\u0930\u093F\u092F Admin \u091C\u093C\u0930\u0942\u0930\u0940 \u0939\u0948 \u2014 \u092A\u0939\u0932\u0947 \u0926\u0942\u0938\u0930\u093E Admin \u092C\u0928\u093E\u090F\u0901");
      }
      await sb("/rest/v1/app_users?username=eq." + encodeURIComponent(uname), { method: "DELETE", headers: { "Prefer": "return=minimal" } });
      return json({ ok: true, result: true });
    }
    switch (op) {
      // workbook/sheet ops → schema के ss_* RPC functions
      case "loadAll":
        return json({ ok: true, result: await rpc("ss_get_all", { p_ss: String(a.ss) }) || {} });
      case "listSS":
        return json({ ok: true, result: await rpc("ss_list_spreadsheets", {}) || [] });
      case "createSS":
        await rpc("ss_create_spreadsheet", { p_id: String(a.id), p_name: String(a.name) });
        return json({ ok: true, result: a.id });
      case "renameSS":
        await rpc("ss_rename_spreadsheet", { p_id: String(a.id), p_name: String(a.name) });
        return json({ ok: true, result: true });
      case "deleteSS":
        await rpc("ss_delete_spreadsheet", { p_id: String(a.id) });
        return json({ ok: true, result: true });
      case "ensureSheet":
        await rpc("ss_ensure_sheet", { p_ss: String(a.ss), p_sheet: String(a.sheet) });
        return json({ ok: true, result: true });
      case "deleteSheet":
        await rpc("ss_delete_sheet", { p_ss: String(a.ss), p_sheet: String(a.sheet) });
        return json({ ok: true, result: true });
      case "renameSheet":
        await rpc("ss_rename_sheet", { p_ss: String(a.ss), p_old: String(a.old), p_new: String(a.neu) });
        return json({ ok: true, result: true });
      case "appendRow":
        return json({ ok: true, result: await rpc("ss_append_row", { p_ss: String(a.ss), p_sheet: String(a.sheet), p_cells: a.cells || [] }) });
      case "setCells":
        await rpc("ss_set_cells", { p_ss: String(a.ss), p_sheet: String(a.sheet), p_row: a.row | 0, p_col: a.col | 0, p_values: a.values || [] });
        return json({ ok: true, result: true });
      case "deleteRow":
        await rpc("ss_delete_row", { p_ss: String(a.ss), p_sheet: String(a.sheet), p_row: a.row | 0 });
        return json({ ok: true, result: true });
      case "clearRange":
        await rpc("ss_clear_range", { p_ss: String(a.ss), p_sheet: String(a.sheet), p_row: a.row | 0, p_col: a.col | 0, p_nrows: a.nrows | 0, p_ncols: a.ncols | 0 });
        return json({ ok: true, result: true });
      // file ops → Supabase Storage + files table
      case "upload": {
        const id = crypto.randomUUID();
        const name = String(a.name || "file");
        const mime = String(a.mime || "application/octet-stream");
        const safe = name.replace(/[\/\\#?%]/g, "_");
        const p = "f/" + id + "/" + safe;
        const bytes = Buffer.from(String(a.base64 || ""), "base64");
        await sb("/storage/v1/object/" + BUCKET + "/" + encPath(p), {
          method: "POST",
          headers: { "content-type": mime, "x-upsert": "true" },
          body: bytes
        });
        await rpc("ss_register_file", { p_id: id, p_path: p, p_name: name, p_folder: String(a.folder || ""), p_mime: mime, p_size: bytes.length });
        return json({ ok: true, result: { id, name, mime, folder: String(a.folder || ""), created: (/* @__PURE__ */ new Date()).toISOString(), url: publicUrl(p) } });
      }
      case "fileRecord": {
        const r = await rpc("ss_file_by_id", { p_id: String(a.id) });
        return json({ ok: true, result: fileOut(r && r.id ? r : null) });
      }
      case "listFolder": {
        const rows = await sb("/rest/v1/files?folder=eq." + encodeURIComponent(String(a.folder || "")) + "&order=created_at.desc") || [];
        return json({ ok: true, result: rows.map(fileOut) });
      }
      case "renameFile":
        await rpc("ss_rename_file", { p_id: String(a.id), p_name: String(a.name) });
        return json({ ok: true, result: true });
      case "deleteFile": {
        const p = await rpc("ss_delete_file", { p_id: String(a.id) });
        if (p) await sb("/storage/v1/object/" + BUCKET + "/" + encPath(p), { method: "DELETE" }).catch(() => {
        });
        return json({ ok: true, result: true });
      }
      case "copyFile": {
        const src = await rpc("ss_file_by_id", { p_id: String(a.id) });
        if (!src || !src.id) return json({ ok: false, error: "file \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u0940" }, 404);
        const nid = crypto.randomUUID();
        const name = String(a.name || src.name);
        const safe = name.replace(/[\/\\#?%]/g, "_");
        const dst = "f/" + nid + "/" + safe;
        await sb("/storage/v1/object/copy", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ bucketId: BUCKET, sourceKey: src.path, destinationKey: dst })
        });
        await rpc("ss_register_file", { p_id: nid, p_path: dst, p_name: name, p_folder: String(a.folder !== void 0 ? a.folder : src.folder), p_mime: src.mime || "", p_size: src.size || 0 });
        return json({ ok: true, result: { id: nid, name, mime: src.mime, folder: String(a.folder !== void 0 ? a.folder : src.folder), created: (/* @__PURE__ */ new Date()).toISOString(), url: publicUrl(dst) } });
      }
      // ── Road Estimator data (est_kv: store/id/data) ──────────
      // NOTE: Estimator per-user isolation फ़िलहाल टाला गया (estimator rebuild तक) — सभी users को सारा
      // estimator डेटा (MoRTH/MoRD master analysis सहित) दिखता है। सिर्फ़ 'master' store की EDIT admin-only है।
      case "estAll": {
        const store = estStore(a.store);
        const rows = await sb("/rest/v1/est_kv?store=eq." + encodeURIComponent(store) + "&select=id,data&order=id") || [];
        return json({ ok: true, result: rows });
      }
      case "estPut": {
        const store = estStore(a.store);
        if (store === "master") requireAdmin(auth);
        await sb("/rest/v1/est_kv", {
          method: "POST",
          headers: { "content-type": "application/json", "Prefer": "resolution=merge-duplicates" },
          body: JSON.stringify([{ store, id: String(a.id), data: a.data, updated_at: (/* @__PURE__ */ new Date()).toISOString() }])
        });
        return json({ ok: true, result: true });
      }
      case "estBulkPut": {
        const store = estStore(a.store);
        if (store === "master") requireAdmin(auth);
        const now = (/* @__PURE__ */ new Date()).toISOString();
        const rows = (a.rows || []).map((r) => ({ store, id: String(r.id), data: r.data, updated_at: now }));
        if (rows.length) await sb("/rest/v1/est_kv", {
          method: "POST",
          headers: { "content-type": "application/json", "Prefer": "resolution=merge-duplicates" },
          body: JSON.stringify(rows)
        });
        return json({ ok: true, result: rows.length });
      }
      case "estStamp":
        return json({ ok: true, result: await rpc("est_stamp", {}) || {} });
      case "estFetchAll":
        return json({ ok: true, result: await rpc("est_all", {}) || {} });
      case "estDel": {
        const store = estStore(a.store);
        if (store === "master") requireAdmin(auth);
        await sb("/rest/v1/est_kv?store=eq." + encodeURIComponent(store) + "&id=eq." + encodeURIComponent(String(a.id)), { method: "DELETE" });
        return json({ ok: true, result: true });
      }
      case "estClear": {
        const store = estStore(a.store);
        if (store === "master") requireAdmin(auth);
        await sb("/rest/v1/est_kv?store=eq." + encodeURIComponent(store), { method: "DELETE" });
        return json({ ok: true, result: true });
      }
      default:
        return json({ ok: false, error: "\u0905\u091C\u094D\u091E\u093E\u0924 op: " + op }, 400);
    }
  } catch (e) {
    return json({ ok: false, error: String(e.message || e) }, e && e._code ? e._code : 500);
  }
};
export {
  config,
  db_default as default
};
